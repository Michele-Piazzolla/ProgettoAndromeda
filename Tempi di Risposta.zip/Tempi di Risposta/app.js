// Importazione dei moduli principali
const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// Middleware per leggere dati dei form e servire file statici
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Imposta il motore di template EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Rotta GET per la home page
app.get('/', (req, res) => {
  res.render('index');
});

// Rotta POST per inviare i risultati
app.post('/result', (req, res) => {
  const nomeutente = req.body.nomeutente;
  const tempi = JSON.parse(req.body.tempi);
  const output = {
    nomeutente,
    tempi_di_reazione: tempi
  };
  res.render('result', { output });
});

// Avvio del server
app.listen(port, () => {
  console.log(`Server attivo su http://localhost:${port}`);
});
