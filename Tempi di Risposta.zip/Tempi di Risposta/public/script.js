// Selezione elementi
const form = document.getElementById('formGioco');
const gioco = document.getElementById('gioco');
const cerchio = document.getElementById('cerchio');
const clickCount = document.getElementById('clickCount');
const overlay = document.getElementById('overlay');
const overlayText = document.getElementById('overlayText');

let tempi = [];
let inAttesa = false;
let livello = 1;
let count = 0;
let timeout;

form.addEventListener('submit', e => {
  e.preventDefault();
  overlayText.innerText = "START";
  mostraOverlay(() => {
    form.style.display = "none";
    gioco.style.display = "block";
    avviaTurno();
  });
});

// Overlay animato
function mostraOverlay(callback, testo = "LIVELLO AVANZATO") {
  overlayText.innerText = testo;
  overlay.style.opacity = 1;
  overlay.style.display = "flex";
  setTimeout(() => {
    overlay.style.opacity = 0;
    setTimeout(() => {
      overlay.style.display = "none";
      callback();
    }, 1000);
  }, 2000);
}

// Gestione click cerchio
cerchio.addEventListener('click', () => {
  if (!inAttesa) return;

  const tempoReazione = new Date().getTime() - cerchio.dataset.start;
  tempi.push(tempoReazione);
  count++;
  clickCount.innerText = count;

  if (count === 10 && livello === 1) {
    livello = 2;
    count = 0;
    clickCount.innerText = 0;
    mostraOverlay(() => {
      avviaTurno();
    }, "LIVELLO AVANZATO");
  } else if (count === 10 && livello === 2) {
    inviaRisultati();
  } else {
    avviaTurno();
  }
});

// Logica turno
function avviaTurno() {
  inAttesa = false;
  cerchio.style.backgroundColor = "red";
  if (livello === 2) {
    cerchio.style.position = "absolute";
    cerchio.style.top = Math.random() * 400 + "px";
    cerchio.style.left = Math.random() * 70 + "%";
  }

  clearTimeout(timeout);
  timeout = setTimeout(() => {
    cerchio.style.backgroundColor = "green";
    cerchio.dataset.start = new Date().getTime();
    inAttesa = true;
  }, Math.random() * 2000 + 1000);
}

// Invio dati al server
function inviaRisultati() {
  const nomeutente = document.getElementById('nomeutente').value;
  const form = document.createElement('form');
  form.method = 'POST';
  form.action = '/result';

  const input1 = document.createElement('input');
  input1.name = 'nomeutente';
  input1.value = nomeutente;
  form.appendChild(input1);

  const input2 = document.createElement('input');
  input2.name = 'tempi';
  input2.value = JSON.stringify(tempi);
  form.appendChild(input2);

  document.body.appendChild(form);
  form.submit();
}
