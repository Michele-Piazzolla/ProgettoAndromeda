package andromeda;

import java.util.*;import java.util.*;
import java.io.*;
/*
public class Andromeda {
    public static class Locandina {
        public String titolo;
        public String data;
        public double prezzoStandard;
        public double prezzoSaltacoda;
        public double prezzoPrive;

        public void reset() {
            titolo = null;
            data = null;
            prezzoStandard = 0;
            prezzoSaltacoda = 0;
            prezzoPrive = 0;
        }
    }

    public static Locandina locandina1 = new Locandina();
    public static Locandina locandina2 = new Locandina();
    public static Locandina locandina3 = new Locandina();

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new Admin().setVisible(true);
            new Clienti().setVisible(true);
        });
    }
   
}
*/
import javax.swing.*;

public class Andromeda {
    // Classe Locandina
    public static class Locandina {
        public String titolo;
        public String data;
        public double prezzoStandard;
        public double prezzoSaltacoda;
        public double prezzoPrive;

        // Metodo per resettare i dati della locandina
        public void reset() {
            titolo = null;
            data = null;
            prezzoStandard = 0;
            prezzoSaltacoda = 0;
            prezzoPrive = 0;
        }
    }

    // Le locandine da gestire
    public static Locandina locandina1 = new Locandina();
    public static Locandina locandina2 = new Locandina();
    public static Locandina locandina3 = new Locandina();
    
    
    
    // Metodo per creare una locandina
    public static void creaLocandina(Locandina locandina) {
        System.out.println("Titolo: " + locandina.titolo);
        System.out.println("Data: " + locandina.data);
        System.out.println("Prezzo Standard: " + locandina.prezzoStandard);
        System.out.println("Prezzo Saltacoda: " + locandina.prezzoSaltacoda);
        System.out.println("Prezzo Prive: " + locandina.prezzoPrive);
    }

    public static void main(String[] args) {
        caricaLocandine();  // <-- Carica i dati da file se esistenti
        // Creazione della GUI
        java.awt.EventQueue.invokeLater(() -> {
            new Admin().setVisible(true);
            new Clienti().setVisible(true);
        });
    }
    
    
    // caricamento locandine su file ;3 per salvataggi
    public static void salvaLocandine() {
    try (java.io.FileWriter writer = new java.io.FileWriter("locandine.txt")) {
        writer.write(locandinaToString(locandina1) + "\n");
        writer.write(locandinaToString(locandina2) + "\n");
        writer.write(locandinaToString(locandina3) + "\n");
    } catch (Exception e) {
        e.printStackTrace();
    }
}

private static String locandinaToString(Locandina l) {
    return l.titolo + ";" + l.data + ";" + l.prezzoStandard + ";" + l.prezzoSaltacoda + ";" + l.prezzoPrive;
}


//per aprire il file locandine sul pc
public static void caricaLocandine() {
    try (java.util.Scanner scanner = new java.util.Scanner(new java.io.File("locandine.txt"))) {
        Locandina[] locandine = { locandina1, locandina2, locandina3 };
        int i = 0;
        while (scanner.hasNextLine() && i < locandine.length) {
            String line = scanner.nextLine();
            String[] dati = line.split(";");
            if (dati.length == 5) {
                locandine[i].titolo = dati[0];
                locandine[i].data = dati[1];
                locandine[i].prezzoStandard = Double.parseDouble(dati[2]);
                locandine[i].prezzoSaltacoda = Double.parseDouble(dati[3]);
                locandine[i].prezzoPrive = Double.parseDouble(dati[4]);
            }
            i++;
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}

}