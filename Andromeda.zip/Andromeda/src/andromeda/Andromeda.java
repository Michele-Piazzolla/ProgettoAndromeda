package andromeda;

import java.util.*;

public class Andromeda {
    
    public static ArrayList<String> clientiRegistrati = new ArrayList<>();

    public static class Locandina {
        public String titolo;
        public String data;
        public double prezzoStandard;
        public double prezzoSaltacoda;
        public double prezzoPrive;

        public void reset() {
            titolo = null;
            data = null;
            prezzoStandard = 0;
            prezzoSaltacoda = 0;
            prezzoPrive = 0;
        }
    }

    public static Locandina locandina1 = new Locandina();
    public static Locandina locandina2 = new Locandina();
    public static Locandina locandina3 = new Locandina();

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new Admin().setVisible(true);
            new Clienti().setVisible(true);
        });
    }
}