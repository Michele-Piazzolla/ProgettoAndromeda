
package andromeda;

public class Biglietto {
    String nomeCliente;
    String evento;
    String data;
    String tipoBiglietto; // Standard, SaltaCoda, Privé
    double prezzo;

    public Biglietto(String nomeCliente, String evento, String data, String tipoBiglietto, double prezzo) {
        this.nomeCliente = nomeCliente;
        this.evento = evento;
        this.data = data;
        this.tipoBiglietto = tipoBiglietto;
        this.prezzo = prezzo;
    }

    public String toFileString() {
        return "Nome: " + nomeCliente + "; Evento: " + evento + "; Data: " + data +
               "; Tipo: " + tipoBiglietto + "; Prezzo: " + prezzo + "€;";
    }
}

