package andromeda;


public class GestioneLocandine {
    private Andromeda.Locandina[] locandine;

    public GestioneLocandine() {
        locandine = new Andromeda.Locandina[3];
        locandine[0] = Andromeda.locandina1;
        locandine[1] = Andromeda.locandina2;
        locandine[2] = Andromeda.locandina3;
    }

    public void impostaLocandina(int indice, String titolo, String data, double standard, double saltacoda, double prive) {
        if (indice >= 0 && indice < locandine.length) {
            Andromeda.Locandina l = locandine[indice];
            l.titolo = titolo;
            l.data = data;
            l.prezzoStandard = standard;
            l.prezzoSaltacoda = saltacoda;
            l.prezzoPrive = prive;
        }
    }

    public Andromeda.Locandina getLocandina(int indice) {
        if (indice >= 0 && indice < locandine.length) {
            return locandine[indice];
        }
        return null;
    }

    public void resetLocandine() {
        for (Andromeda.Locandina l : locandine) {
            l.reset();
        }
    }

    public int getNumeroLocandine() {
        return locandine.length;
    }
}

