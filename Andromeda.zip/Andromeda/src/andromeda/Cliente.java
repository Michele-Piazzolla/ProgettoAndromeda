package andromeda;

public class Cliente {
    private String nome;
    private String cognome;
    private String email;
    private String telefono;
    private String evento;
    private String dataEvento;
    private String tipoBiglietto;
    private double prezzo;

    public Cliente(String nome, String cognome, String email, String telefono,
                   String evento, String dataEvento, String tipoBiglietto, double prezzo) {
        this.nome = nome;
        this.cognome = cognome;
        this.email = email;
        this.telefono = telefono;
        this.evento = evento;
        this.dataEvento = dataEvento;
        this.tipoBiglietto = tipoBiglietto;
        this.prezzo = prezzo;
    }

    @Override
    public String toString() {
        return String.format("Nome: %s %s; Mail: %s; Evento: %s; Data: %s; Tipo biglietto: %s; Prezzo: %.2f€;",
                nome, cognome, email, evento, dataEvento, tipoBiglietto, prezzo);
    }
}

