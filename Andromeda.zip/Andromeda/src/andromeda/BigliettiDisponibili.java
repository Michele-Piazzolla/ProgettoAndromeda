
package andromeda;

public class BigliettiDisponibili {
    private int bigliettiIntero = 20;
    private int bigliettiRidotto = 20;
    private int bigliettiSaltaCoda = 10;

    public boolean bigliettoDisponibile(String tipo) {
        switch (tipo) {
            case "Intero":
                return bigliettiIntero > 0;
            case "Ridotto":
                return bigliettiRidotto > 0;
            case "SaltaCoda":
                return bigliettiSaltaCoda > 0;
            default:
                return false;
        }
    }

    public boolean acquistaBiglietto(String tipo) {
        if (bigliettoDisponibile(tipo)) {
            switch (tipo) {
                case "Intero":
                    bigliettiIntero--;
                    break;
                case "Ridotto":
                    bigliettiRidotto--;
                    break;
                case "SaltaCoda":
                    bigliettiSaltaCoda--;
                    break;
            }
            return true;
        }
        return false;
    }

    public int getDisponibilita(String tipo) {
        switch (tipo) {
            case "Intero":
                return bigliettiIntero;
            case "Ridotto":
                return bigliettiRidotto;
            case "SaltaCoda":
                return bigliettiSaltaCoda;
            default:
                return 0;
        }
    }
}

