package andromeda;

import javax.swing.JOptionPane;

public class Clienti extends javax.swing.JFrame {

    public Clienti() {
        initComponents();
         aggiornaLocandine(); // << aggiungi questa riga!
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        NomeUtente = new javax.swing.JTextField();
        CognomeUtente = new javax.swing.JTextField();
        MailUtente = new javax.swing.JTextField();
        TelefonoUtente = new javax.swing.JTextField();
        BottoneAcquistoBigliettoBase = new javax.swing.JButton();
        BottoneAcquistoBigliettoSaltaCoda = new javax.swing.JButton();
        BottoneAcquistoBigliettoPrive = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        MessaggioVerifica = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        SelezionaEvento2 = new javax.swing.JRadioButton();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        SelezionaEvento3 = new javax.swing.JRadioButton();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        SelezionaEvento1 = new javax.swing.JRadioButton();
        titolo1 = new javax.swing.JLabel();
        data1 = new javax.swing.JLabel();
        ticket1 = new javax.swing.JLabel();
        saltacoda1 = new javax.swing.JLabel();
        prive1 = new javax.swing.JLabel();
        titolo2 = new javax.swing.JLabel();
        data2 = new javax.swing.JLabel();
        ticket2 = new javax.swing.JLabel();
        saltacoda2 = new javax.swing.JLabel();
        prive2 = new javax.swing.JLabel();
        titolo3 = new javax.swing.JLabel();
        data3 = new javax.swing.JLabel();
        ticket3 = new javax.swing.JLabel();
        saltacoda3 = new javax.swing.JLabel();
        prive3 = new javax.swing.JLabel();
        aggiornaButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Benvenuto, Prenota il tuo biglietto!");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/andromeda/Flyer Open.png"))); // NOI18N

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/andromeda/Flyer Open.png"))); // NOI18N

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/andromeda/Flyer Open.png"))); // NOI18N

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel2.setText("INSERISCI QUI I TUOI DATI PER L'ACQUISTO");

        jLabel4.setText("Nome");

        jLabel22.setText("Cognome");

        jLabel23.setText("Mail");

        jLabel24.setText("Numero di Telefono");

        NomeUtente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NomeUtenteActionPerformed(evt);
            }
        });

        CognomeUtente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CognomeUtenteActionPerformed(evt);
            }
        });

        MailUtente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MailUtenteActionPerformed(evt);
            }
        });

        TelefonoUtente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TelefonoUtenteActionPerformed(evt);
            }
        });

        BottoneAcquistoBigliettoBase.setText("Acquista Biglietto Base");
        BottoneAcquistoBigliettoBase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BottoneAcquistoBigliettoBaseActionPerformed(evt);
            }
        });

        BottoneAcquistoBigliettoSaltaCoda.setText("Acquista Salta Coda");
        BottoneAcquistoBigliettoSaltaCoda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BottoneAcquistoBigliettoSaltaCodaActionPerformed(evt);
            }
        });

        BottoneAcquistoBigliettoPrive.setText("Acquista Privè");
        BottoneAcquistoBigliettoPrive.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BottoneAcquistoBigliettoPriveActionPerformed(evt);
            }
        });

        jLabel25.setText("Seleziona Tipo la tipologia di biglietto da acquistare :");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel24)
                            .addComponent(jLabel23)
                            .addComponent(jLabel4)
                            .addComponent(jLabel22))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(CognomeUtente, javax.swing.GroupLayout.DEFAULT_SIZE, 238, Short.MAX_VALUE)
                            .addComponent(NomeUtente)
                            .addComponent(MailUtente)
                            .addComponent(TelefonoUtente))))
                .addGap(4, 4, 4)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BottoneAcquistoBigliettoSaltaCoda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(BottoneAcquistoBigliettoBase, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(BottoneAcquistoBigliettoPrive, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, 313, Short.MAX_VALUE))
                        .addGap(13, 13, 13))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(MessaggioVerifica, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(22, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator2)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(MessaggioVerifica)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(BottoneAcquistoBigliettoBase)
                        .addGap(8, 8, 8)
                        .addComponent(BottoneAcquistoBigliettoSaltaCoda)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(BottoneAcquistoBigliettoPrive)
                        .addGap(1, 1, 1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(NomeUtente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel22)
                            .addComponent(CognomeUtente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel23)
                            .addComponent(MailUtente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel24)
                            .addComponent(TelefonoUtente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(10, Short.MAX_VALUE))
        );

        jLabel26.setText("TITOLO :");

        jLabel27.setText("DATA : ");

        jLabel28.setText("PREZZO TICKET :");

        jLabel29.setText("PREZZO SALTACODA  :");

        jLabel30.setText("PREZZO PRIVÉ :");

        SelezionaEvento2.setText("Seleziona Evento");
        SelezionaEvento2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelezionaEvento2ActionPerformed(evt);
            }
        });

        jLabel31.setText("TITOLO :");

        jLabel32.setText("DATA : ");

        jLabel33.setText("PREZZO TICKET :");

        jLabel34.setText("PREZZO SALTACODA  :");

        jLabel35.setText("PREZZO PRIVÉ :");

        SelezionaEvento3.setText("Seleziona Evento");
        SelezionaEvento3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelezionaEvento3ActionPerformed(evt);
            }
        });

        jLabel36.setText("TITOLO :");

        jLabel37.setText("DATA : ");

        jLabel38.setText("PREZZO TICKET :");

        jLabel39.setText("PREZZO SALTACODA  :");

        jLabel40.setText("PREZZO PRIVÉ :");

        SelezionaEvento1.setText("Seleziona Evento");
        SelezionaEvento1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelezionaEvento1ActionPerformed(evt);
            }
        });

        aggiornaButton.setText("Aggiorna");
        aggiornaButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aggiornaButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(47, 47, 47)
                        .addComponent(aggiornaButton)
                        .addGap(10, 10, 10))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jSeparator1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel36)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(titolo1))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel39)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(saltacoda1))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel40)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(prive1))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                .addComponent(jLabel37)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(data1))
                                            .addComponent(jLabel38, javax.swing.GroupLayout.Alignment.LEADING))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(ticket1))
                                    .addComponent(SelezionaEvento1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel27)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(data2))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel29)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(saltacoda2))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel30)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(prive2))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                .addComponent(jLabel26)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(titolo2))
                                            .addComponent(jLabel28, javax.swing.GroupLayout.Alignment.LEADING))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(ticket2))
                                    .addComponent(SelezionaEvento2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel32)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(data3))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel31)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(titolo3))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel35)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(prive3))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel33)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(ticket3))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel34)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(saltacoda3))
                                    .addComponent(SelezionaEvento3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel5))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(aggiornaButton)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel6)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel26)
                            .addComponent(titolo2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel27)
                            .addComponent(data2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel28)
                            .addComponent(ticket2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel29)
                            .addComponent(saltacoda2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel30)
                            .addComponent(prive2))
                        .addGap(12, 12, 12)
                        .addComponent(SelezionaEvento2))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel31)
                            .addComponent(titolo3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel32)
                            .addComponent(data3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel33)
                            .addComponent(ticket3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel34)
                            .addComponent(saltacoda3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel35)
                            .addComponent(prive3))
                        .addGap(12, 12, 12)
                        .addComponent(SelezionaEvento3))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel36)
                            .addComponent(titolo1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel37)
                            .addComponent(data1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel38)
                            .addComponent(ticket1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel39)
                            .addComponent(saltacoda1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel40)
                            .addComponent(prive1))
                        .addGap(12, 12, 12)
                        .addComponent(SelezionaEvento1)))
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void aggiornaLocandine() {
    // Locandina 1
    titolo1.setText(Andromeda.locandina1.titolo != null ? Andromeda.locandina1.titolo : "Evento non Attivo!");
    data1.setText(Andromeda.locandina1.data != null ? Andromeda.locandina1.data : "...");
    ticket1.setText(Andromeda.locandina1.prezzoStandard != 0 ? String.valueOf(Andromeda.locandina1.prezzoStandard) : "...");
    saltacoda1.setText(Andromeda.locandina1.prezzoSaltacoda != 0 ? String.valueOf(Andromeda.locandina1.prezzoSaltacoda) : "...");
    prive1.setText(Andromeda.locandina1.prezzoPrive != 0 ? String.valueOf(Andromeda.locandina1.prezzoPrive) : "...");

    // Locandina 2
    titolo2.setText(Andromeda.locandina2.titolo != null ? Andromeda.locandina2.titolo : "Evento non Attivo!");
    data2.setText(Andromeda.locandina2.data != null ? Andromeda.locandina2.data : "...");
    ticket2.setText(Andromeda.locandina2.prezzoStandard != 0 ? String.valueOf(Andromeda.locandina2.prezzoStandard) : "...");
    saltacoda2.setText(Andromeda.locandina2.prezzoSaltacoda != 0 ? String.valueOf(Andromeda.locandina2.prezzoSaltacoda) : "...");
    prive2.setText(Andromeda.locandina2.prezzoPrive != 0 ? String.valueOf(Andromeda.locandina2.prezzoPrive) : "...");


    // Locandina 3 
    titolo3.setText(Andromeda.locandina3.titolo != null ? Andromeda.locandina3.titolo : "Evento non Attivo!");
    data3.setText(Andromeda.locandina3.data != null ? Andromeda.locandina3.data : "...");
    ticket3.setText(Andromeda.locandina3.prezzoStandard != 0 ? String.valueOf(Andromeda.locandina3.prezzoStandard) : "...");
    saltacoda3.setText(Andromeda.locandina3.prezzoSaltacoda != 0 ? String.valueOf(Andromeda.locandina3.prezzoSaltacoda) : "...");
    prive3.setText(Andromeda.locandina3.prezzoPrive != 0 ? String.valueOf(Andromeda.locandina3.prezzoPrive) : "...");

    }
    
    private void registraCliente(String tipoBiglietto) {
    String nome = NomeUtente.getText();
    String cognome = CognomeUtente.getText();
    String mail = MailUtente.getText();
    String telefono = TelefonoUtente.getText();
    
    // Verifica campi vuoti
    if (nome.isEmpty() || cognome.isEmpty() || mail.isEmpty() || telefono.isEmpty()) {
        MessaggioVerifica.setText("️Compila tutti i campi!");
        return;
    }

    // Verifica evento selezionato
    int eventiSelezionati = 0;
    String eventoScelto = "";
    if (SelezionaEvento1.isSelected()) {
        eventiSelezionati++;
        eventoScelto = Andromeda.locandina1.titolo;
    }
    if (SelezionaEvento2.isSelected()) {
        eventiSelezionati++;
        eventoScelto = Andromeda.locandina2.titolo;
    }
    if (SelezionaEvento3.isSelected()) {
        eventiSelezionati++;
        eventoScelto = Andromeda.locandina3.titolo;
    }

    if (eventiSelezionati != 1) {
        MessaggioVerifica.setText("Seleziona *uno* e *solo uno* evento!");
        return;
    }

    // Costruisci stringa cliente
    String datiCliente = "Nome: " + nome + " " + cognome +
                         " | Tel: " + telefono +
                         " | Email: " + mail +
                         " | Evento: " + eventoScelto +
                         " | Biglietto: " + tipoBiglietto;

    // Salva
    Andromeda.clientiRegistrati.add(datiCliente);

    // Conferma
    MessaggioVerifica.setText("Acquisto registrato!");

    // Pulizia campi (opzionale)
    NomeUtente.setText("");
    CognomeUtente.setText("");
    MailUtente.setText("");
    TelefonoUtente.setText("");
    SelezionaEvento1.setSelected(false);
    SelezionaEvento2.setSelected(false);
    SelezionaEvento3.setSelected(false);
}

    
    private void NomeUtenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NomeUtenteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NomeUtenteActionPerformed

    private void CognomeUtenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CognomeUtenteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CognomeUtenteActionPerformed

    private void MailUtenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MailUtenteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MailUtenteActionPerformed

    private void TelefonoUtenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TelefonoUtenteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TelefonoUtenteActionPerformed

    private void SelezionaEvento2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelezionaEvento2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SelezionaEvento2ActionPerformed

    private void SelezionaEvento3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelezionaEvento3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SelezionaEvento3ActionPerformed

    private void SelezionaEvento1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelezionaEvento1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SelezionaEvento1ActionPerformed

    private void aggiornaButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aggiornaButtonActionPerformed
        aggiornaLocandine();
    }//GEN-LAST:event_aggiornaButtonActionPerformed

    private void BottoneAcquistoBigliettoBaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BottoneAcquistoBigliettoBaseActionPerformed
         registraCliente("Base");
    }//GEN-LAST:event_BottoneAcquistoBigliettoBaseActionPerformed

    private void BottoneAcquistoBigliettoSaltaCodaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BottoneAcquistoBigliettoSaltaCodaActionPerformed
        registraCliente("Salta Coda");
    }//GEN-LAST:event_BottoneAcquistoBigliettoSaltaCodaActionPerformed

    private void BottoneAcquistoBigliettoPriveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BottoneAcquistoBigliettoPriveActionPerformed
        registraCliente("Privè");
    }//GEN-LAST:event_BottoneAcquistoBigliettoPriveActionPerformed
    
private void acquistaBiglietto() {

    Andromeda.Locandina locandinaScelta = null;
    
    if (SelezionaEvento1.isSelected()) {
        locandinaScelta = Andromeda.locandina1;
    } 
    else if (SelezionaEvento2.isSelected()) {
        locandinaScelta = Andromeda.locandina2;
    } 
    else if (SelezionaEvento3.isSelected()) {
        locandinaScelta = Andromeda.locandina3;
    }
    
    
    String nome = NomeUtente.getText();
    String cognome = CognomeUtente.getText();
    
    JOptionPane.showMessageDialog(this, 
        "Biglietto acquistato con successo per: " + locandinaScelta.titolo + 
        "\nCliente: " + nome + " " + cognome +
        "\nPrezzo: €" + locandinaScelta.prezzoStandard
    );
}

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Clienti.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Clienti.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Clienti.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Clienti.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Clienti().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BottoneAcquistoBigliettoBase;
    private javax.swing.JButton BottoneAcquistoBigliettoPrive;
    private javax.swing.JButton BottoneAcquistoBigliettoSaltaCoda;
    private javax.swing.JTextField CognomeUtente;
    private javax.swing.JTextField MailUtente;
    private javax.swing.JLabel MessaggioVerifica;
    private javax.swing.JTextField NomeUtente;
    private javax.swing.JRadioButton SelezionaEvento1;
    private javax.swing.JRadioButton SelezionaEvento2;
    private javax.swing.JRadioButton SelezionaEvento3;
    private javax.swing.JTextField TelefonoUtente;
    private javax.swing.JButton aggiornaButton;
    private javax.swing.JLabel data1;
    private javax.swing.JLabel data2;
    private javax.swing.JLabel data3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel prive1;
    private javax.swing.JLabel prive2;
    private javax.swing.JLabel prive3;
    private javax.swing.JLabel saltacoda1;
    private javax.swing.JLabel saltacoda2;
    private javax.swing.JLabel saltacoda3;
    private javax.swing.JLabel ticket1;
    private javax.swing.JLabel ticket2;
    private javax.swing.JLabel ticket3;
    private javax.swing.JLabel titolo1;
    private javax.swing.JLabel titolo2;
    private javax.swing.JLabel titolo3;
    // End of variables declaration//GEN-END:variables
}
