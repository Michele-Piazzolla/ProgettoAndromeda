package andromeda;

import javax.swing.*;
import java.io.*;
import java.util.*;
public class Clienti extends javax.swing.JFrame {
    BigliettiDisponibili disponibilita = new BigliettiDisponibili();
    int bigliettiInteroDisponibili = 20;
int bigliettiRidottoDisponibili = 20;
int bigliettiSaltaCodaDisponibili = 10;

// Prezzi dinamici da assegnare all’avvio
double prezzoIntero = 0;
double prezzoRidotto = 0;
double prezzoSaltaCoda = 0;

// Date evento dinamiche da assegnare all’avvio
String dataEvento1 = "";
String dataEvento2 = "";
String dataEvento3 = "";

    public Clienti() {
        initComponents();aggiornaLocandine(); 
        aggiornaLocandine(); 
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        CopertinaLocandina2 = new javax.swing.JLabel();
        CopertinaLocandina3 = new javax.swing.JLabel();
        CopertinaLocandina1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        InserisciNome = new javax.swing.JTextField();
        InserisciCognome = new javax.swing.JTextField();
        InserisciMail = new javax.swing.JTextField();
        InserisciNumTel = new javax.swing.JTextField();
        AcquistaBigliettoBase = new javax.swing.JButton();
        AcqustaSaltaCoda = new javax.swing.JButton();
        AcquistaPrive = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        SelezionaEvento2 = new javax.swing.JRadioButton();
        SelezionaEvento3 = new javax.swing.JRadioButton();
        SelezionaEvento1 = new javax.swing.JRadioButton();
        TitoloLocandina1 = new javax.swing.JLabel();
        DataLocandina1 = new javax.swing.JLabel();
        PrezzoTicketLocandina1 = new javax.swing.JLabel();
        PrezzoSaltaCoda1 = new javax.swing.JLabel();
        PrezzoPrive1 = new javax.swing.JLabel();
        TitoloLocandina2 = new javax.swing.JLabel();
        DataLocandina2 = new javax.swing.JLabel();
        PrezzoTicketLocandina2 = new javax.swing.JLabel();
        PrezzoSaltaCoda2 = new javax.swing.JLabel();
        PrezzoPrive2 = new javax.swing.JLabel();
        TitoloLocandina3 = new javax.swing.JLabel();
        DataLocandina3 = new javax.swing.JLabel();
        PrezzoTicketLocandina3 = new javax.swing.JLabel();
        PrezzoSaltaCoda3 = new javax.swing.JLabel();
        PrezzoPrive3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Benvenuto, Prenota il tuo biglietto!");

        CopertinaLocandina2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/andromeda/Flyer Open.png"))); // NOI18N

        CopertinaLocandina3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/andromeda/Flyer Open.png"))); // NOI18N

        CopertinaLocandina1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/andromeda/Flyer Open.png"))); // NOI18N

        jLabel7.setText("TITOLO :");

        jLabel8.setText("DATA : ");

        jLabel9.setText("PREZZO TICKET :");

        jLabel10.setText("PREZZO SALTACODA  :");

        jLabel11.setText("PREZZO PRIVÉ :");

        jLabel12.setText("DATA : ");

        jLabel13.setText("PREZZO TICKET :");

        jLabel14.setText("PREZZO SALTACODA  :");

        jLabel15.setText("PREZZO PRIVÉ :");

        jLabel16.setText("TITOLO :");

        jLabel17.setText("DATA : ");

        jLabel18.setText("PREZZO TICKET :");

        jLabel19.setText("PREZZO SALTACODA  :");

        jLabel20.setText("PREZZO PRIVÉ :");

        jLabel21.setText("TITOLO :");

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setText("INSERISCI QUI I TUOI DATI PER L'ACQUISTO");

        jLabel4.setText("Nome");

        jLabel22.setText("Cognome");

        jLabel23.setText("Mail");

        jLabel24.setText("Numero di Telefono");

        InserisciNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InserisciNomeActionPerformed(evt);
            }
        });

        InserisciCognome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InserisciCognomeActionPerformed(evt);
            }
        });

        InserisciMail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InserisciMailActionPerformed(evt);
            }
        });

        InserisciNumTel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InserisciNumTelActionPerformed(evt);
            }
        });

        AcquistaBigliettoBase.setText("Acquista Biglietto Base");
        AcquistaBigliettoBase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AcquistaBigliettoBaseActionPerformed(evt);
            }
        });

        AcqustaSaltaCoda.setText("Acquista Salta Coda");
        AcqustaSaltaCoda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AcqustaSaltaCodaActionPerformed(evt);
            }
        });

        AcquistaPrive.setText("Acquista Privè");
        AcquistaPrive.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AcquistaPriveActionPerformed(evt);
            }
        });

        jLabel25.setText("Seleziona Tipo la tipologia di biglietto da acquistare :");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel24)
                            .addComponent(jLabel23)
                            .addComponent(jLabel4)
                            .addComponent(jLabel22))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(InserisciCognome, javax.swing.GroupLayout.DEFAULT_SIZE, 238, Short.MAX_VALUE)
                            .addComponent(InserisciNome)
                            .addComponent(InserisciMail)
                            .addComponent(InserisciNumTel))))
                .addGap(4, 4, 4)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(AcqustaSaltaCoda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AcquistaBigliettoBase, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AcquistaPrive, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, 313, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(13, 13, 13))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator2)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(AcquistaBigliettoBase)
                        .addGap(8, 8, 8)
                        .addComponent(AcqustaSaltaCoda)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(AcquistaPrive)
                        .addGap(1, 1, 1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(InserisciNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel22)
                            .addComponent(InserisciCognome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel23)
                            .addComponent(InserisciMail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel24)
                            .addComponent(InserisciNumTel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(10, Short.MAX_VALUE))
        );

        SelezionaEvento2.setText("Seleziona Evento");
        SelezionaEvento2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelezionaEvento2ActionPerformed(evt);
            }
        });

        SelezionaEvento3.setText("Seleziona Evento");
        SelezionaEvento3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelezionaEvento3ActionPerformed(evt);
            }
        });

        SelezionaEvento1.setText("Seleziona Evento");
        SelezionaEvento1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelezionaEvento1ActionPerformed(evt);
            }
        });

        TitoloLocandina1.setText("jLabel26");

        DataLocandina1.setText("jLabel27");

        PrezzoTicketLocandina1.setText("jLabel28");

        PrezzoSaltaCoda1.setText("jLabel29");

        PrezzoPrive1.setText("jLabel30");

        TitoloLocandina2.setText("jLabel31");

        DataLocandina2.setText("jLabel32");

        PrezzoTicketLocandina2.setText("jLabel33");

        PrezzoSaltaCoda2.setText("jLabel34");

        PrezzoPrive2.setText("jLabel35");

        TitoloLocandina3.setText("jLabel36");

        DataLocandina3.setText("jLabel37");

        PrezzoTicketLocandina3.setText("jLabel38");

        PrezzoSaltaCoda3.setText("jLabel39");

        PrezzoPrive3.setText("jLabel40");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jSeparator1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(CopertinaLocandina1)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel8)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(DataLocandina1))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel7)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(TitoloLocandina1))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(6, 6, 6)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(jLabel11)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(PrezzoPrive1))
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(jLabel9)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(PrezzoTicketLocandina1))
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(jLabel10)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(PrezzoSaltaCoda1)))))))
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(CopertinaLocandina2)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel16)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(TitoloLocandina2, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(jLabel12)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(DataLocandina2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(6, 6, 6)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(jLabel15)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(jLabel14)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                    .addComponent(PrezzoSaltaCoda2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(jLabel13)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                    .addComponent(PrezzoTicketLocandina2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel21)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(TitoloLocandina3))
                                    .addComponent(CopertinaLocandina3)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel17)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(DataLocandina3))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel20)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(PrezzoPrive3))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel18)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(PrezzoTicketLocandina3))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel19)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(PrezzoSaltaCoda3))))))
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(PrezzoPrive2, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(SelezionaEvento1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(SelezionaEvento2, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SelezionaEvento3, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(CopertinaLocandina2)
                    .addComponent(CopertinaLocandina1)
                    .addComponent(CopertinaLocandina3))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(TitoloLocandina2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(DataLocandina2)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel21)
                            .addComponent(TitoloLocandina3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel17)
                            .addComponent(DataLocandina3)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(TitoloLocandina1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(DataLocandina1))))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18)
                            .addComponent(PrezzoTicketLocandina3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(PrezzoSaltaCoda3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(PrezzoPrive3)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(PrezzoTicketLocandina2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(PrezzoSaltaCoda2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(PrezzoPrive2)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(PrezzoTicketLocandina1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(PrezzoSaltaCoda1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(PrezzoPrive1))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SelezionaEvento2)
                    .addComponent(SelezionaEvento1)
                    .addComponent(SelezionaEvento3))
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(99, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void aggiornaLocandine() {
    // Locandina 1
    TitoloLocandina1.setText(Andromeda.locandina1.titolo != null ? Andromeda.locandina1.titolo : "Evento non Attivo!");
    DataLocandina1.setText(Andromeda.locandina1.data != null ? Andromeda.locandina1.data : "...");
    PrezzoTicketLocandina1.setText(Andromeda.locandina1.prezzoStandard != 0 ? String.valueOf(Andromeda.locandina1.prezzoStandard) : "...");
    PrezzoSaltaCoda1.setText(Andromeda.locandina1.prezzoSaltacoda != 0 ? String.valueOf(Andromeda.locandina1.prezzoSaltacoda) : "...");
    PrezzoPrive1.setText(Andromeda.locandina1.prezzoPrive != 0 ? String.valueOf(Andromeda.locandina1.prezzoPrive) : "...");

    // Locandina 2
    TitoloLocandina2.setText(Andromeda.locandina2.titolo != null ? Andromeda.locandina1.titolo : "Evento non Attivo!");
    DataLocandina2.setText(Andromeda.locandina2.data != null ? Andromeda.locandina1.data : "...");
    PrezzoTicketLocandina2.setText(Andromeda.locandina2.prezzoStandard != 0 ? String.valueOf(Andromeda.locandina1.prezzoStandard) : "...");
    PrezzoSaltaCoda2.setText(Andromeda.locandina2.prezzoSaltacoda != 0 ? String.valueOf(Andromeda.locandina1.prezzoSaltacoda) : "...");
    PrezzoPrive2.setText(Andromeda.locandina2.prezzoPrive != 0 ? String.valueOf(Andromeda.locandina1.prezzoPrive) : "...");


    // Locandina 3 
    TitoloLocandina3.setText(Andromeda.locandina3.titolo != null ? Andromeda.locandina1.titolo : "Evento non Attivo!");
    DataLocandina3.setText(Andromeda.locandina3.data != null ? Andromeda.locandina1.data : "...");
    PrezzoTicketLocandina3.setText(Andromeda.locandina3.prezzoStandard != 0 ? String.valueOf(Andromeda.locandina1.prezzoStandard) : "...");
    PrezzoSaltaCoda3.setText(Andromeda.locandina3.prezzoSaltacoda != 0 ? String.valueOf(Andromeda.locandina1.prezzoSaltacoda) : "...");
    PrezzoPrive3.setText(Andromeda.locandina3.prezzoPrive != 0 ? String.valueOf(Andromeda.locandina1.prezzoPrive) : "...");

    }
    
    
    private void InserisciNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InserisciNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_InserisciNomeActionPerformed

    private void InserisciCognomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InserisciCognomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_InserisciCognomeActionPerformed

    private void InserisciMailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InserisciMailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_InserisciMailActionPerformed

    private void InserisciNumTelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InserisciNumTelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_InserisciNumTelActionPerformed

    private void SelezionaEvento3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelezionaEvento3ActionPerformed
     
    }//GEN-LAST:event_SelezionaEvento3ActionPerformed

    private void SelezionaEvento1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelezionaEvento1ActionPerformed
      
    }//GEN-LAST:event_SelezionaEvento1ActionPerformed

    private void SelezionaEvento2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelezionaEvento2ActionPerformed

    }//GEN-LAST:event_SelezionaEvento2ActionPerformed

    private void AcquistaBigliettoBaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AcquistaBigliettoBaseActionPerformed
        if (!datiValidi()) {
        jLabel3.setText("DATI MANCANTI");
        return;
    }

    if (bigliettiInteroDisponibili > 0) {
        Cliente cliente = creaCliente("Intero", prezzoIntero);
        if (cliente == null) return;
        salvaClienteSuFile(cliente);
        bigliettiInteroDisponibili--;
        jLabel3.setText("Biglietto Intero acquistato con successo!");
    } else {
        jLabel3.setText("Biglietti Intero esauriti.");
    }
    }//GEN-LAST:event_AcquistaBigliettoBaseActionPerformed

    private void AcqustaSaltaCodaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AcqustaSaltaCodaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AcqustaSaltaCodaActionPerformed

    private void AcquistaPriveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AcquistaPriveActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AcquistaPriveActionPerformed
    private boolean datiValidi() {
    return !InserisciNome.getText().isEmpty() &&
           !InserisciCognome.getText().isEmpty() &&
           !InserisciMail.getText().isEmpty() &&
           !InserisciNumTel.getText().isEmpty();
    }
    private Cliente creaCliente(String tipoBiglietto, double prezzo) {
    String nome = InserisciNome.getText().trim();
    String cognome = InserisciCognome.getText().trim();
    String email = InserisciMail.getText().trim();
    String telefono = InserisciNumTel.getText().trim();
    //String evento = comboBoxEvento.getSelectedItem().toString();
    String evento = "";
    String dataEvento = "";

    if (SelezionaEvento1.isSelected()) {
        evento = SelezionaEvento1.getText();
        dataEvento = dataEvento1;
    } else if (SelezionaEvento2.isSelected()) {
        evento = SelezionaEvento2.getText();
        dataEvento = dataEvento2;
    } else if (SelezionaEvento3.isSelected()) {
        evento = SelezionaEvento3.getText();
        dataEvento = dataEvento3;
    } else {
        jLabel3.setText("Seleziona un evento!");
        return null;
    }

    return new Cliente(nome, cognome, email, telefono, evento, dataEvento, tipoBiglietto, prezzo);
}
    private void salvaClienteSuFile(Cliente cliente) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter("clienti.txt", true))) {
        writer.write(cliente.toString());
        writer.newLine(); // aggiunge una nuova riga dopo ogni cliente
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Errore durante il salvataggio del cliente: " + e.getMessage());
    }
}



private void acquistaBiglietto() {

    Andromeda.Locandina locandinaScelta = null;
    
    if (SelezionaEvento2.isSelected()) {
        locandinaScelta = Andromeda.locandina1;
    } 
    else if (SelezionaEvento3.isSelected()) {
        locandinaScelta = Andromeda.locandina2;
    } 
    else if (SelezionaEvento1.isSelected()) {
        locandinaScelta = Andromeda.locandina3;
    }
    
    if (locandinaScelta == null) {
        JOptionPane.showMessageDialog(this, "Seleziona una locandina prima!");
        return;
    }
    
    if (locandinaScelta.titolo == null || locandinaScelta.titolo.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Locandina ancora Vuota!");
        return;
    }
    
    String nome = InserisciNome.getText();
    String cognome = InserisciCognome.getText();
    
    JOptionPane.showMessageDialog(this, 
        "Biglietto acquistato con successo per: " + locandinaScelta.titolo + 
        "\nCliente: " + nome + " " + cognome +
        "\nPrezzo: €" + locandinaScelta.prezzoStandard
    );
}

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Clienti.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Clienti.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Clienti.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Clienti.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Clienti().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AcquistaBigliettoBase;
    private javax.swing.JButton AcquistaPrive;
    private javax.swing.JButton AcqustaSaltaCoda;
    private javax.swing.JLabel CopertinaLocandina1;
    private javax.swing.JLabel CopertinaLocandina2;
    private javax.swing.JLabel CopertinaLocandina3;
    private javax.swing.JLabel DataLocandina1;
    private javax.swing.JLabel DataLocandina2;
    private javax.swing.JLabel DataLocandina3;
    private javax.swing.JTextField InserisciCognome;
    private javax.swing.JTextField InserisciMail;
    private javax.swing.JTextField InserisciNome;
    private javax.swing.JTextField InserisciNumTel;
    private javax.swing.JLabel PrezzoPrive1;
    private javax.swing.JLabel PrezzoPrive2;
    private javax.swing.JLabel PrezzoPrive3;
    private javax.swing.JLabel PrezzoSaltaCoda1;
    private javax.swing.JLabel PrezzoSaltaCoda2;
    private javax.swing.JLabel PrezzoSaltaCoda3;
    private javax.swing.JLabel PrezzoTicketLocandina1;
    private javax.swing.JLabel PrezzoTicketLocandina2;
    private javax.swing.JLabel PrezzoTicketLocandina3;
    private javax.swing.JRadioButton SelezionaEvento1;
    private javax.swing.JRadioButton SelezionaEvento2;
    private javax.swing.JRadioButton SelezionaEvento3;
    private javax.swing.JLabel TitoloLocandina1;
    private javax.swing.JLabel TitoloLocandina2;
    private javax.swing.JLabel TitoloLocandina3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    // End of variables declaration//GEN-END:variables
}
