// =====================
// IMPORTAZIONE DEI MODULI NECESSARI
// =====================
const express = require('express');        // Importa il framework Express per creare il server
const app = express();                     // Crea un'istanza dell'applicazione Express
const fs = require('fs');                  // Importa il modulo File System per leggere/scrivere file
const bodyParser = require('body-parser'); // Middleware per analizzare i dati provenienti dai form HTML

// =====================
// CONFIGURAZIONE DELLA PORTA
// =====================
const porta = 3000;                        // Porta su cui il server sarà in ascolto

// =====================
// IMPOSTAZIONI INIZIALI DI EXPRESS
// =====================
app.set('view engine', 'ejs');             // Imposta EJS come motore di template per generare HTML dinamico
app.use(express.static('public'));         // Rende accessibili i file nella cartella 'public' (es. CSS, immagini)
app.use(bodyParser.urlencoded({ extended: true })); // Permette di leggere i dati dei form (POST)

// =====================
// VARIABILI GLOBALI
// =====================
let carrello = []; // Array per memorizzare i prodotti nel carrello dell’utente

// =====================
// CARICAMENTO UTENTI SALVATI
// =====================
let utentiClienti = JSON.parse(fs.readFileSync('./dati/users-clienti.json', 'utf-8')); // Carica utenti clienti dal file
let utentiVenditori = JSON.parse(fs.readFileSync('./dati/users-venditori.json', 'utf-8')); // Carica utenti venditori dal file

// =====================
// ROTTE PRINCIPALI
// =====================
app.get('/', (req, res) => {              // Rotta principale: reindirizza alla pagina di login
  res.redirect('/login');                 // Reindirizza a /login
});

app.get('/login', (req, res) => {         // Rotta GET per visualizzare la pagina di login
  res.render('login');                    // Mostra la view login.ejs
});

// =====================
// LOGIN CLIENTE
// =====================
app.post('/login-cliente', (req, res) => {      // Rotta POST per il login del cliente
  const { username, password } = req.body;      // Estrae username e password dal form

  let utente = utentiClienti.find(u => u.username === username); // Cerca l’utente tra quelli registrati

  if (!utente) {                                 // Se non esiste, lo registra
    utentiClienti.push({ username, password });  // Aggiunge il nuovo cliente all'array

    fs.writeFileSync('./dati/users-clienti.json', JSON.stringify(utentiClienti, null, 2)); // Salva il file aggiornato
  }

  res.redirect('/home');                         // Reindirizza alla home del cliente
});

// =====================
// LOGIN VENDITORE
// =====================
app.post('/login-venditore', (req, res) => {     // Rotta POST per il login del venditore
  const { username, password } = req.body;       // Estrae username e password dal form

  let utente = utentiVenditori.find(u => u.username === username); // Cerca il venditore registrato

  if (!utente) {                                 // Se non esiste, lo registra
    utentiVenditori.push({ username, password }); // Aggiunge il nuovo venditore all'array

    fs.writeFileSync('./dati/users-venditori.json', JSON.stringify(utentiVenditori, null, 2)); // Salva il file aggiornato
  }

  res.redirect('/venditore');                    // Reindirizza alla pagina riservata ai venditori
});

// =====================
// HOME CLIENTE
// =====================
app.get('/home', (req, res) => {                 // Rotta GET per visualizzare la home del cliente
  const prodotti = JSON.parse(fs.readFileSync('./dati/prodotti.json')); // Carica tutti i prodotti

  res.render('home', { prodotti, carrelloCount: carrello.length }); // Mostra la home con i prodotti e il numero di articoli nel carrello
});

// =====================
// DETTAGLIO PRODOTTO
// =====================
app.get('/prodotto/:id', (req, res) => {               // Rotta GET per il dettaglio di un prodotto specifico
  const prodotti = JSON.parse(fs.readFileSync('./dati/prodotti.json')); // Carica i prodotti

  const prodotto = prodotti.find(p => p.id == req.params.id); // Trova il prodotto con ID corrispondente

  if (prodotto) {                                       // Se trovato
    res.render('prodotto', { prodotto, carrelloCount: carrello.length }); // Mostra la pagina del prodotto
  } else {                                              // Altrimenti
    res.status(404).send('Prodotto non trovato');       // Risponde con errore 404
  }
});

// =====================
// AGGIUNTA AL CARRELLO
// =====================
app.post('/aggiungi-carrello', (req, res) => {         // Rotta POST per aggiungere un prodotto al carrello
  const { id, nome, prezzo } = req.body;               // Estrae i dati del prodotto dal form

  carrello.push({ id, nome, prezzo: parseFloat(prezzo) }); // Aggiunge il prodotto al carrello (con prezzo come numero)

  res.redirect('/home');                               // Torna alla home dopo l'aggiunta
});

// =====================
// PAGINA CARRELLO
// =====================
app.get('/carrello', (req, res) => {                   // Rotta GET per visualizzare il carrello
  const totale = carrello.reduce((sum, item) => sum + item.prezzo, 0); // Calcola il totale del carrello

  res.render('carrello', {                             // Mostra la pagina del carrello
    carrello,
    carrelloCount: carrello.length,
    totale
  });
});

// =====================
// RIMOZIONE DAL CARRELLO
// =====================
app.post('/rimuovi-carrello/:id', (req, res) => {      // Rotta POST per rimuovere un prodotto dal carrello
  carrello = carrello.filter(item => item.id != req.params.id); // Rimuove il prodotto con ID specifico

  res.redirect('/carrello');                           // Torna alla pagina del carrello
});

// =====================
// PAGINA DEL VENDITORE
// =====================
app.get('/venditore', (req, res) => {                  // Rotta GET per la pagina riservata ai venditori
  res.render('venditore');                             // Mostra il form per creare un nuovo prodotto
});

// =====================
// CREAZIONE NUOVO PRODOTTO
// =====================
app.post('/crea-prodotto', (req, res) => {             // Rotta POST per creare un nuovo prodotto
  const { nome, prezzo, immagine, descrizione, venditore } = req.body; // Estrae i dati dal form

  const prodotti = JSON.parse(fs.readFileSync('./dati/prodotti.json')); // Carica i prodotti esistenti

  const nuovoProdotto = {                              // Crea un nuovo oggetto prodotto
    id: prodotti.length > 0 ? prodotti[prodotti.length - 1].id + 1 : 1, // Imposta un ID progressivo
    nome,
    prezzo: parseFloat(prezzo),                        // Converte il prezzo in numero
    immagine,
    descrizione,
    venditore
  };

  prodotti.push(nuovoProdotto);                        // Aggiunge il nuovo prodotto alla lista

  fs.writeFileSync('./dati/prodotti.json', JSON.stringify(prodotti, null, 2)); // Salva la nuova lista su file

  res.redirect('/venditore');                          // Torna alla pagina del venditore
});

// =====================
// AVVIO DEL SERVER
// =====================
app.listen(porta, () => {                              // Avvia il server sulla porta specificata
  console.log(`Server avviato su http://localhost:${porta}`); // Messaggio in console al lancio
});
